int main(void) {

 yylex();  /* < inicia el autómata */
	

 return 0;
}
